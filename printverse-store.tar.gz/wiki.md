Project Summary
The project is a comprehensive e-commerce platform for selling unique 3D-printed keychains. It allows users to browse, filter, and purchase a variety of keychains while providing an admin panel for managing products and orders. The platform leverages modern web technologies to ensure a responsive and user-friendly experience.

Project Module Description
User Interface: Main pages include the homepage, product catalog, product detail, cart, and checkout.
Admin Panel: Features for managing products, viewing orders, and updating order statuses.
Localization: Supports both Ukrainian and English languages.
Product Management: Admins can add, edit, or delete products and manage inventory.
Directory Tree
shadcn-ui/
├── README.md                   # Project overview and setup instructions
├── components.json             # Component definitions
├── eslint.config.js            # ESLint configuration for code quality
├── index.html                  # Main HTML file for the application
├── package.json                # Project dependencies and scripts
├── postcss.config.js           # PostCSS configuration
├── public/
│   ├── favicon.svg             # Favicon for the application
│   └── robots.txt              # Robots.txt for SEO
├── src/
│   ├── App.css                 # Main CSS styles
│   ├── App.tsx                 # Main application component
│   ├── components/             # Reusable UI components
│   ├── hooks/                  # Custom hooks
│   ├── lib/                    # Utility functions and types
│   ├── pages/                  # Page components for routing
│   ├── index.css               # Global CSS styles
│   ├── vite-env.d.ts           # Type definitions for Vite
│   ├── vite.config.ts          # Vite configuration
├── tailwind.config.ts          # Tailwind CSS configuration
└── tsconfig.*.json             # TypeScript configuration files
File Description Inventory
README.md: Documentation for project setup and usage.
src/App.tsx: Main application logic and routing.
src/pages/: Contains all page components like Index, ProductCatalog, and AdminDashboard.
src/components/: Contains reusable UI components such as Header, ProductCard, and LanguageProvider.
src/lib/: Contains utility functions, mock data, and type definitions.
src/hooks/: Custom React hooks for state management.
Technology Stack
Frontend: React, TypeScript, Tailwind CSS, Vite
State Management: Custom local storage management
UI Components: shadcn/ui, lucide-react
Linting: ESLint for code quality
Package Management: pnpm
Usage
Install Dependencies: Run the command to install all necessary packages.
Build the Project: Execute the build command to prepare the application for production.
Run the Application: Start the development server to view the application in a browser.